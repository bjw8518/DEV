﻿namespace MusicPlayerApp
{
    partial class MusicPlayer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MusicPlayer));
            this.PlayList = new System.Windows.Forms.ListBox();
            this.btnSM = new System.Windows.Forms.Button();
            this.axWindowsMediaPlayerMusic = new AxWMPLib.AxWindowsMediaPlayer();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayerMusic)).BeginInit();
            this.SuspendLayout();
            // 
            // PlayList
            // 
            resources.ApplyResources(this.PlayList, "PlayList");
            this.PlayList.FormattingEnabled = true;
            this.PlayList.Name = "PlayList";
            this.PlayList.SelectedIndexChanged += new System.EventHandler(this.listBoxSongs_SelectedIndexChanged);
            // 
            // btnSM
            // 
            this.btnSM.BackColor = System.Drawing.Color.MediumSlateBlue;
            resources.ApplyResources(this.btnSM, "btnSM");
            this.btnSM.ForeColor = System.Drawing.Color.White;
            this.btnSM.Name = "btnSM";
            this.btnSM.UseVisualStyleBackColor = false;
            this.btnSM.Click += new System.EventHandler(this.btnSelectMusic_Click);
            // 
            // axWindowsMediaPlayerMusic
            // 
            resources.ApplyResources(this.axWindowsMediaPlayerMusic, "axWindowsMediaPlayerMusic");
            this.axWindowsMediaPlayerMusic.Name = "axWindowsMediaPlayerMusic";
            this.axWindowsMediaPlayerMusic.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWindowsMediaPlayerMusic.OcxState")));
            // 
            // MusicPlayer
            // 
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.axWindowsMediaPlayerMusic);
            this.Controls.Add(this.btnSM);
            this.Controls.Add(this.PlayList);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "MusicPlayer";
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayerMusic)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ListBox PlayList;
        private System.Windows.Forms.Button btnSM;
        private AxWMPLib.AxWindowsMediaPlayer axWindowsMediaPlayerMusic;
    }
}

