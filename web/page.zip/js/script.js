function openNav() {
        document.getElementById('mysidenav').style.width = '250px';
    }
    function closeNav() {
        document.getElementById('mysidenav').style.width = '0';
    }